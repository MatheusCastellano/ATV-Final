package com.example.myapplication

class SistemaLogin {
    private val usuarios = mutableMapOf<String, String>()

    // Adiciona um novo usuário
    fun cadastrarUsuario(usuario: String, senha: String): Boolean {
        return if (usuarios.containsKey(usuario)) {
            false // Usuário já cadastrado
        } else {
            usuarios[usuario] = senha
            true // Cadastro bem-sucedido
        }
    }

    // Verifica se o login é válido
    fun validarLogin(usuario: String, senha: String): Boolean {
        return usuarios[usuario] == senha
    }
}
