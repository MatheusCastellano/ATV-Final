package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        setupButtonClickListeners()
        setupAccessoriesRecyclerView()
    }

    private fun setupButtonClickListeners() {
        val buttonIds = listOf(R.id.botaoTerno1, R.id.botaoTernos2, R.id.botaoTernos3, R.id.botaoTernos4)
        val productActivities = listOf(
            Terno_Gola_Notch::class.java,
            Terno_Colete_Gola_Shaw::class.java,
            Terno_Colete_Calca::class.java,
            Terno_Contraste::class.java
        )

        buttonIds.forEachIndexed { index, buttonId ->
            findViewById<Button>(buttonId).setOnClickListener {
                val intent = Intent(this, productActivities[index]).apply {
                    putExtra("NOME_USUARIO", intent.getStringExtra("NOME_USUARIO") ?: "Usuário")
                }
                startActivity(intent)
            }
        }
    }

    private fun setupAccessoriesRecyclerView() {
        val recyclerView = findViewById<RecyclerView>(R.id.accessoriesRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recyclerView.adapter = SuitAccessoryAdapter(SuitAccessories.accessories) { accessory ->
            Toast.makeText(this, "Selecionado: ${accessory.name}", Toast.LENGTH_SHORT).show()
            // Aqui você pode adicionar lógica adicional, como abrir uma nova Activity com detalhes do acessório
        }
    }

    override fun onBackPressed() {
        // Chama o método da superclasse para manter o comportamento padrão
        super.onBackPressed()
        // Adicione aqui qualquer lógica adicional que você queira executar quando o botão "Voltar" for pressionado
    }
}
