package com.example.myapplication

import androidx.annotation.DrawableRes

data class SuitAccessory(
    val id: Int,
    val name: String,
    val description: String,
    val price: Double,
    @DrawableRes val imageResId: Int
)

object SuitAccessories {
    val accessories = listOf(
        SuitAccessory(1, "Gravata de Seda", "Elegante gravata de seda em padrão listrado", 89.99, R.drawable.gravata),
        SuitAccessory(2, "Abotoaduras de Prata", "Abotoaduras de prata com detalhes em ônix", 129.99, R.drawable.abotoadores),
        SuitAccessory(3, "Lenço de Bolso", "Lenço de bolso em seda pura com padrão paisley", 49.99, R.drawable.lenço),
        SuitAccessory(4, "Cinto de Couro", "Cinto de couro italiano com fivela prateada", 79.99, R.drawable.cinto),
        SuitAccessory(5, "Suspensórios", "Suspensórios elásticos ajustáveis em preto", 59.99, R.drawable.suspensorio),
        SuitAccessory(6, "Prendedor de Gravata", "Prendedor de gravata em ouro rosé", 69.99, R.drawable.prendedor),
        SuitAccessory(7, "Anel de Aço", "Par de meias de seda em padrão geométrico", 39.99, R.drawable.anel),
        SuitAccessory(8, "Sapatos Oxford", "Sapatos Oxford em couro preto polido", 249.99, R.drawable.sapato),
        SuitAccessory(9, "Carteira de Couro", "Carteira slim de couro genuíno", 89.99, R.drawable.carteira),
        SuitAccessory(10, "Relógio de Pulso", "Relógio de pulso analógico com pulseira de couro", 299.99, R.drawable.relogio)
    )

    fun getAccessoryById(id: Int): SuitAccessory? {
        return accessories.find { it.id == id }
    }

    fun getAccessoriesByPriceRange(minPrice: Double, maxPrice: Double): List<SuitAccessory> {
        return accessories.filter { it.price in minPrice..maxPrice }
    }
}

