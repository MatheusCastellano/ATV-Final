package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Terno_Colete_Gola_Shaw : AppCompatActivity() {
    private lateinit var userName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terno_colete_gola_shaw)

        userName = intent.getStringExtra("NOME_USUARIO") ?: "Usuário"

        val imageView = findViewById<ImageView>(R.id.suitImageView)
        val nameTextView = findViewById<TextView>(R.id.suitNameTextView)
        val descriptionTextView = findViewById<TextView>(R.id.suitDescriptionTextView)
        val priceTextView = findViewById<TextView>(R.id.suitPriceTextView)
        val buyButton = findViewById<Button>(R.id.buyButton)

        imageView.setImageResource(R.drawable.terno2)
        nameTextView.text = "Terno com Colete e Gola Shaw"
        descriptionTextView.text = "Terno sofisticado com colete e gola Shaw para ocasiões especiais."
        priceTextView.text = "R$ 1399,99"

        setupAccessoriesRecyclerView()

        buyButton.setOnClickListener {
            showPurchaseConfirmationDialog()
        }
    }

    private fun setupAccessoriesRecyclerView() {
        val recyclerView = findViewById<RecyclerView>(R.id.accessoriesRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recyclerView.adapter = SuitAccessoryAdapter(SuitAccessories.accessories) { accessory ->
            Toast.makeText(this, "Selecionado: ${accessory.name}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showPurchaseConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Confirmar Compra")
            .setMessage("Deseja finalizar a compra do Terno com Colete e Gola Shaw?")
            .setPositiveButton("Sim") { _, _ ->
                finalizePurchase()
            }
            .setNegativeButton("Não", null)
            .show()
    }

    private fun finalizePurchase() {
        simulateInvoiceDownload()
    }

    private fun simulateInvoiceDownload() {
        Toast.makeText(this, "Iniciando download da nota fiscal...", Toast.LENGTH_SHORT).show()
        android.os.Handler().postDelayed({
            showDownloadCompletedDialog()
        }, 2000)
    }

    private fun showDownloadCompletedDialog() {
        AlertDialog.Builder(this)
            .setTitle("Download Concluído")
            .setMessage("A nota fiscal foi baixada com sucesso para a conta de $userName.")
            .setPositiveButton("OK") { _, _ ->
                finish()
            }
            .show()
    }
}
