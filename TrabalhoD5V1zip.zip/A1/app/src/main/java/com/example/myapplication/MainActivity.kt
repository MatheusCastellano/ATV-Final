package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.ViewTreeObserver
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {
    private val sistemaLogin = SistemaLogin()
    private val TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val scrollView = findViewById<ScrollView>(R.id.scrollView)
        val entradaUsuario = findViewById<EditText>(R.id.entradaUsuario)
        val entradaSenhaLayout = findViewById<TextInputLayout>(R.id.entradaSenhaLayout)
        val entradaSenha = findViewById<EditText>(R.id.entradaSenha)
        val botaoLogin = findViewById<Button>(R.id.botaoLogin)
        val botaoCadastro = findViewById<Button>(R.id.botaoCadastro)

        // Set up keyboard behavior
        ViewCompat.setOnApplyWindowInsetsListener(scrollView) { v, insets ->
            val imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(0, 0, 0, imeInsets.bottom)
            insets
        }

        // Ensure password is not visible by default
        entradaSenhaLayout.endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
        entradaSenha.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD

        // Scroll to focused view when keyboard appears
        scrollView.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            private var lastHeight = 0

            override fun onGlobalLayout() {
                val newHeight = scrollView.height
                if (lastHeight != 0 && newHeight < lastHeight) {
                    scrollView.post {
                        scrollView.smoothScrollTo(0, scrollView.bottom)
                    }
                }
                lastHeight = newHeight
            }
        })

        // Lógica de login
        botaoLogin.setOnClickListener {
            val usuario = entradaUsuario.text.toString().trim()
            val senha = entradaSenha.text.toString().trim()

            if (usuario.isNotEmpty() && senha.isNotEmpty()) {
                if (sistemaLogin.validarLogin(usuario, senha)) {
                    Log.d(TAG, "Login bem-sucedido para o usuário: $usuario")
                    Toast.makeText(this, "Bem-vindo, $usuario!", Toast.LENGTH_SHORT).show()

                    // Criar Intent para iniciar MainActivity2
                    val intent = Intent(this, MainActivity3::class.java).apply {
                        putExtra("NOME_USUARIO", usuario)
                    }

                    // Iniciar MainActivity2 sem finalizar MainActivity
                    startActivity(intent)
                } else {
                    Log.d(TAG, "Tentativa de login falhou para o usuário: $usuario")
                    Toast.makeText(this, "Usuário ou senha incorretos!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Log.d(TAG, "Tentativa de login com campos vazios")
                Toast.makeText(this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }

        // Lógica de cadastro
        botaoCadastro.setOnClickListener {
            val usuario = entradaUsuario.text.toString().trim()
            val senha = entradaSenha.text.toString().trim()

            if (usuario.isNotEmpty() && senha.isNotEmpty()) {
                if (sistemaLogin.cadastrarUsuario(usuario, senha)) {
                    Log.d(TAG, "Cadastro bem-sucedido para o usuário: $usuario")
                    Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show()
                } else {
                    Log.d(TAG, "Tentativa de cadastro falhou para o usuário: $usuario")
                    Toast.makeText(this, "Usuário já existe!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Log.d(TAG, "Tentativa de cadastro com campos vazios")
                Toast.makeText(this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

