package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SuitAccessoryAdapter(
    private val accessories: List<SuitAccessory>,
    private val onItemClick: ((SuitAccessory) -> Unit)? = null
) : RecyclerView.Adapter<SuitAccessoryAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.accessoryImage)
        val name: TextView = view.findViewById(R.id.accessoryName)
        val price: TextView = view.findViewById(R.id.accessoryPrice)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_suit_accessory, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val accessory = accessories[position]
        holder.image.setImageResource(accessory.imageResId)
        holder.name.text = accessory.name
        holder.price.text = "R$ %.2f".format(accessory.price)

        holder.itemView.setOnClickListener {
            onItemClick?.invoke(accessory)
        }
    }

    override fun getItemCount() = accessories.size
}

